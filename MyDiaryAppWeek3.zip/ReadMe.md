# Diary Application

## Overview

This Java console application allows users to create, edit, and delete daily notes. Diary entries are saved locally using file-based persistence (via Java serialization), ensuring that your notes persist between sessions.

## Features

- **Add Note:**  
  Create a new diary entry for the current day.
  
- **Edit Note:**  
  Update an existing diary note by its ID.
  
- **Delete Note:**  
  Remove a diary note by its ID.
  
- **View All Notes:**  
  List all diary entries with their ID, date, and content.
  
- **Local Data Persistence:**  
  Diary entries are saved to a file (`diary.dat`), ensuring that your notes persist across sessions.

## Setup

### Prerequisites

- **Java JDK:** Version 22 or later.
- **Maven (Optional):** For compiling and packaging the project.

### Building the Project

#### Using Maven:
1. Navigate to the project directory (where the `pom.xml` file is located, if available).
2. Run:
   ```bash
   mvn clean package
   ```
This command creates an executable JAR file in the `target` directory.

#### Without Maven:
Compile the Java files manually:
```bash
javac -d bin src/com/virtunexa/*.java
```

### Running the Application

#### Using the JAR File:
```bash
java -jar target/YourJarName.jar
```
*(Replace "YourJarName.jar" with the actual name of the generated JAR file.)*

#### Without Maven:
From the `bin` directory:
```bash
java com.virtunexa.Main
```

## Usage

1. **Launch the Application:**  
   The diary is automatically loaded from `diary.dat` (if it exists); otherwise, a new diary is started.

2. **Diary Menu:**
    - **Add Daily Note:** Create a new note for the current day.
    - **Edit Note:** Edit an existing note by entering its ID.
    - **Delete Note:** Delete a note by entering its ID.
    - **View All Notes:** List all diary entries.
    - **Exit:** Save all entries and exit the application.

3. **Input:**  
   Follow the on-screen prompts to create, modify, or delete diary entries.

### Example Interaction

```
-------- Diary Menu --------
1. Add Daily Note
2. Edit Note
3. Delete Note
4. View All Notes
5. Exit
Enter your choice: 1
--- Add Daily Note ---
Date: 2025-03-15
Enter note content:
Today I started using my new diary app.
Note added successfully with ID: 1

-------- Diary Menu --------
1. Add Daily Note
2. Edit Note
3. Delete Note
4. View All Notes
5. Exit
Enter your choice: 4
--- All Diary Notes ---
---------------
ID: 1 | Date: 2025-03-15
Today I started using my new diary app.
---------------
```

## Final Thoughts

This Diary Application is a practical tool for managing daily notes and serves as an example of Java programming concepts such as file I/O, serialization, and console-based user interfaces. For any questions or feedback, please feel free to reach out.
