package com.virtunexa;

import java.io.Serializable;
import java.time.LocalDate;

public class DiaryEntry implements Serializable {
    private static final long serialVersionUID = 1L;
    private int id;
    private LocalDate date;
    private String content;

    public DiaryEntry(int id, LocalDate date, String content) {
        this.id = id;
        this.date = date;
        this.content = content;
    }

    public int getId() {
        return id;
    }

    public LocalDate getDate() {
        return date;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "ID: " + id + " | Date: " + date + "\n" + content;
    }
}
