package com.virtunexa;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import java.io.IOException;

public class DiaryCLI {
    private DiaryManager manager;
    private Scanner scanner;

    public DiaryCLI() {
        manager = new DiaryManager();
        scanner = new Scanner(System.in);
        try {
            manager.loadFromFile();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("No previous diary found. Starting a new diary.");
        }
    }

    public void start() {
        boolean exit = false;
        while (!exit) {
            System.out.println("\n-------- Diary Menu --------");
            System.out.println("1. Add Daily Note");
            System.out.println("2. Edit Note");
            System.out.println("3. Delete Note");
            System.out.println("4. View All Notes");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            String choice = scanner.nextLine().trim();
            switch (choice) {
                case "1":
                    addNote();
                    break;
                case "2":
                    editNote();
                    break;
                case "3":
                    deleteNote();
                    break;
                case "4":
                    viewNotes();
                    break;
                case "5":
                    exit = true;
                    saveEntries();
                    System.out.println("Exiting diary. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
        scanner.close();
    }

    private void addNote() {
        System.out.println("\n--- Add Daily Note ---");
        int id = manager.getNextId();
        LocalDate date = LocalDate.now();
        System.out.println("Date: " + date);
        System.out.println("Enter note content:");
        String content = scanner.nextLine();
        DiaryEntry entry = new DiaryEntry(id, date, content);
        manager.addEntry(entry);
        System.out.println("Note added successfully with ID: " + id);
    }

    private void editNote() {
        System.out.println("\n--- Edit Note ---");
        System.out.print("Enter note ID to edit: ");
        int id;
        try {
            id = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID.");
            return;
        }
        DiaryEntry entry = manager.getEntryById(id);
        if (entry == null) {
            System.out.println("Note not found.");
            return;
        }
        System.out.println("Current content:\n" + entry.getContent());
        System.out.println("Enter new content:");
        String newContent = scanner.nextLine();
        entry.setContent(newContent);
        System.out.println("Note updated successfully.");
    }

    private void deleteNote() {
        System.out.println("\n--- Delete Note ---");
        System.out.print("Enter note ID to delete: ");
        int id;
        try {
            id = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID.");
            return;
        }
        boolean success = manager.deleteEntry(id);
        if (success) {
            System.out.println("Note deleted successfully.");
        } else {
            System.out.println("Note not found.");
        }
    }

    private void viewNotes() {
        System.out.println("\n--- All Diary Notes ---");
        List<DiaryEntry> entries = manager.getEntries();
        if (entries.isEmpty()) {
            System.out.println("No diary notes available.");
        } else {
            for (DiaryEntry entry : entries) {
                System.out.println("---------------");
                System.out.println(entry);
            }
            System.out.println("---------------");
        }
    }

    private void saveEntries() {
        try {
            manager.saveToFile();
            System.out.println("Diary saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving diary: " + e.getMessage());
        }
    }
}
