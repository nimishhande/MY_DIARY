package com.virtunexa;

public class Main {
    public static void main(String[] args) {
        DiaryCLI cli = new DiaryCLI();
        cli.start();
    }
}
