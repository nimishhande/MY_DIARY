package com.virtunexa;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class DiaryManager {
    private List<DiaryEntry> entries;
    private static final String FILE_NAME = "diary.dat";

    public DiaryManager() {
        entries = new ArrayList<>();
    }

    public List<DiaryEntry> getEntries() {
        return entries;
    }

    public void addEntry(DiaryEntry entry) {
        entries.add(entry);
    }

    public DiaryEntry getEntryById(int id) {
        for (DiaryEntry entry : entries) {
            if (entry.getId() == id) {
                return entry;
            }
        }
        return null;
    }

    public boolean deleteEntry(int id) {
        DiaryEntry entry = getEntryById(id);
        if (entry != null) {
            entries.remove(entry);
            return true;
        }
        return false;
    }

    // Saves diary entries to a file using serialization.
    public void saveToFile() throws IOException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            oos.writeObject(entries);
        }
    }

    // Loads diary entries from a file.
    public void loadFromFile() throws IOException, ClassNotFoundException {
        File file = new File(FILE_NAME);
        if (!file.exists()) {
            entries = new ArrayList<>();
            return;
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            entries = (List<DiaryEntry>) ois.readObject();
        }
    }

    // Returns the next available ID for a new diary entry.
    public int getNextId() {
        int maxId = 0;
        for (DiaryEntry entry : entries) {
            if (entry.getId() > maxId) {
                maxId = entry.getId();
            }
        }
        return maxId + 1;
    }
}
